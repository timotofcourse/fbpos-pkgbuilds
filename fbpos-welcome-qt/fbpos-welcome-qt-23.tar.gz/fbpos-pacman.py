#!/usr/bin/env python

import pacman
import os
import argparse
import time

parser = argparse.ArgumentParser(description='Backend for fbpos-welcome.')

parser.add_argument('--update', type=str, help='yes/no')
parser.add_argument('--install', type=str, help='packagename')

args = parser.parse_args()


if args.install == None:
    if args.update == 'yes':
        pacman.refresh()
    else:
        time.sleep(0)
else:
    package = args.install
    pacman.install(package)
