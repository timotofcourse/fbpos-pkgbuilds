#!/usr/bin/env python

import subprocess
import sys
from PySide2.QtUiTools import *
from PySide2.QtWidgets import *
from PySide2.QtCore import *

# Define funcions

def opensettings():
    subprocess.run("systemsettings", shell=False)

        
def opentimeshift():
    subprocess.run("pkexec timeshift-gtk", shell=True)

def installnvidia():
    nvinstall = subprocess.Popen("pkexec pacman -S nvidia nvidia-utils nvidia-settings", shell=True)
    nvinstall.wait()
    subprocess.run('zenity --info --text="Nvidia Driver Installed"', shell=True)

def installoptimus():
    optim1 = subprocess.Popen("pkexec pacman -S bumblebee", shell=True)
    optim1.wait()
    optim2 = subprocess.Popen("yay -S envycontrol optimus-manager optimus-manager-qt-kde", shell=True)
    optim2.wait()
    subprocess.run('zenity --info --text="Nvidia Optimus Installed"', shell=True)

def opensoftware():
    subprocess.run("gnome-software", shell=False)

def installgames():
    gameinstall = subprocess.Popen("pkexec pacaman -S steam heroic-games-launcher-beta pcsx2 minecraft-launcher", shell=True)
    gameinstall.wait()
    subprocess.run('zenity --info --text="Game Set Installed"', shell=True)

def installoffice():
    officeinstall = subprocess.Popen("pkexec pacman -S wps-office", shell=True)
    officeinstall.wait()
    subprocess.run('zenity --info --text="Office Suite Installed"', shell=True)

def security():
    secinstall = subprocess.Popen("pkexec pacman -S authy bitwarden", shell=True)
    secinstall.wait()
    subprocess.run('zenity --info --text="Security Set Installed"', shell=True)

def remote():
    rem = subprocess.Popen("pkexec pacman -S rustdesk", shell=True)
    rem.wait()
    subprocess.run('zenity --info --text="Remote Control Set Installed"', shell=True)

# Load UI

if __name__ == "__main__":

    # Basic UI Load Things

    app = QApplication(sys.argv)

    ui_file_name = "/usr/share/fbpos-welcome/fbpos-welcome.ui"
    ui_file = QFile(ui_file_name)
    if not ui_file.open(QIODevice.ReadOnly):
        print("Cannot open {}: {}".format(ui_file_name, ui_file.errorString()))
        sys.exit(-1)
    loader = QUiLoader()
    window = loader.load(ui_file)
    ui_file.close()
    if not window:
        print(loader.errorString())
        sys.exit(-1)
    
    # Code to Make UI work

    window.pushButton.clicked.connect(opensettings)
    window.pushButton_2.clicked.connect(opentimeshift)
    window.pushButton_3.clicked.connect(installnvidia)
    window.pushButton_4.clicked.connect(installoptimus)
    window.pushButton_5.clicked.connect(opensoftware)
    window.pushButton_6.clicked.connect(installgames)
    window.pushButton_7.clicked.connect(installoffice)
    window.pushButton_8.clicked.connect(security)
    window.pushButton_9.clicked.connect(remote)

    # Show UI

    window.show()
    sys.exit(app.exec_())
